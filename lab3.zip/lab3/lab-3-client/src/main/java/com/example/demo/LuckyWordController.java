/**
 * 
 */
package com.example.demo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.CompositePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Phani Achanta
 *
 */
@RestController
public class LuckyWordController {

    @Autowired
	HashMap<String,String> rules;
    @Autowired
    HashMap<String, String> messages;
  
	 @GetMapping("/lucky-word")
	  public String showLuckyWord() {
		 System.out.println(rules);
		 System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4");
		 System.out.println(messages);
	    return "The lucky word is:" ;
	  }
	 
	    
	    
}