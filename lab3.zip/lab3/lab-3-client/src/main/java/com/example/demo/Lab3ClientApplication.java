package com.example.demo;

import java.util.HashMap;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.CompositePropertySource;
import org.springframework.core.env.Environment;


@SpringBootApplication
public class Lab3ClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab3ClientApplication.class, args);
	}
	
	
	    
	    @Autowired
		  private Environment    env;
	
	 @Bean(name = "rules")
	 @RefreshScope
	 public  HashMap<String,String> getRules() {
	    HashMap<String, String> rules = new HashMap<String, String>();
	    
	    CompositePropertySource bootstrapProperties = (CompositePropertySource)  ((AbstractEnvironment) env).getPropertySources().get("bootstrapProperties");
	     for (String propertyName : bootstrapProperties.getPropertyNames()) {
	    	 if(propertyName.startsWith("rule")) {
	    		 rules.put(propertyName, (String) bootstrapProperties.getProperty(propertyName));
	    	 }
	    	  
	    } 
	    System.out.println("*************************************************************************************************************************************************************************8");
	    System.out.println( rules);
	    return rules;
	  }
	  @Bean(name = "messages")
	  @RefreshScope
	  public HashMap<String,String>  getMessages() {
		   
		    HashMap<String, String> messages = new HashMap<String, String>();
		    
		    CompositePropertySource bootstrapProperties = (CompositePropertySource)  ((AbstractEnvironment) env).getPropertySources().get("bootstrapProperties");
		     for (String propertyName : bootstrapProperties.getPropertyNames()) {
		    	 
		    	 if(propertyName.startsWith("message")) {
		    		 messages.put(propertyName, (String) bootstrapProperties.getProperty(propertyName));
		    	 }
		    } 
		 
		    
		  
		    System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		    System.out.println( messages);
		    return messages;
		  }
		  
	  
	  
	  @Autowired
	    @Qualifier("rules")
	    HashMap<String, String> rules;
	    
	    @Autowired
	    @Qualifier("messages")
	    HashMap<String, String> messages;
	    
	  

	 
}

