/**
 * 
 */
package demo;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @author Phani Achanta
 *
 */
@Component
@RefreshScope
@ConfigurationProperties(prefix = "validation")
public class ConfigurationApp {
	
	 String nullPwd;
	 String success;
	 public String getNullPwd() {
		return nullPwd;
	}
	public void setNullPwd(String nullPwd) {
		this.nullPwd = nullPwd;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Map<String, String> getRules() {
		return rules;
	}
	public void setRules(Map<String, String> rules) {
		this.rules = rules;
	}
	public Map<String, String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(Map<String, String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	String  message;
	 Map<String,String> rules;
	 Map<String,String> errorMessages;
	 
	

}


 