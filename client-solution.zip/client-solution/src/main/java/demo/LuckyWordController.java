package demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LuckyWordController {
	 
@Autowired
ConfigurationApp configurationApp;

 
	  
	  @GetMapping("/lucky-word")
	  public String showLuckyWord() {
		  System.out.println("********"+configurationApp.getRules());
		  System.out.println("********"+configurationApp.getMessage());
		  System.out.println("********"+configurationApp.getNullPwd());
		  System.out.println("********"+configurationApp.toString());
	    return "The lucky word is: " + configurationApp. getMessage();
	  }
}
